//
//  ViewController.swift
//  UserNotes
//
//  Created by Bear Cahill on 6/27/18.
//  Copyright © 2018 Bear Cahill. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        testAPI()
    }

    func testAPI() {
        let newItem = UserNote.init(id: "333", text: "from the app")
        DefaultAPI.userNotesFuncPost(userNote: newItem) { (resp, error) in
            print (error?.localizedDescription ?? "no error")
            
            DefaultAPI.userNotesFuncGet(completion: { (notes, error) in
                notes?.forEach({ (note) in
                    print ("\(note.id) \(note.text)")
                })
                DefaultAPI.userNotesFuncNoteIDGet(noteID: "333", completion: { (note, error) in
                    print (note?.id ?? "no id")
                    
                    DefaultAPI.userNotesFuncNoteIDDelete(noteID: "333", completion: { (resp, error) in
                        print (error?.localizedDescription ?? "success")
                    })
                })
            })
        }
    }
}









